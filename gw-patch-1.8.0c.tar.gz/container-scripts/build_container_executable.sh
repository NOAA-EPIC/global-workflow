#!/bin/bash
#set -x
export img=IMAGE
export SINGULARITYENV_FI_PROVIDER=tcp
export SINGULARITYENV_FI_PROVIDER_PATH=FI_PATH
export SINGULARITY_SHELL=/bin/bash
export SINGULARITYENV_PATH=EXEC_PATH
export SINGULARITYENV_LD_LIBRARY_PATH=LDLIB_PATH
export SINGULARITYENV_LIBRARY_PATH=LIB_PATH
export SINGULARITYENV_CMAKE_PREFIX_PATH=CMAKE_PREPATH
export SINGULARITYENV_ESMFMKFILE=ESMF_MK
cmd=$(basename "$0")
arg="$@"
echo running: singularity exec "${img}" $cmd $arg
singularity exec -e BINDDIRS "${img}" $cmd $arg

